// ============================================================================
// timer.c - VERSÃO CORRIGIDA PARA POLLING USB MAIS RÁPIDO
// ============================================================================
// MUDANÇA: TICK_MS reduzido de 10ms para 2ms
// Isso aumenta a frequência de polling de 100Hz para 500Hz
// 
// Se 2ms ainda for lento, tente 1ms.
// ============================================================================

#include "timer.h"
#include "../timer/hpet.h"
#include "../apic/lapic.h"
#include "../shell/shell.h"
#include "../graphics/console.h"

extern void xhci_poll_events(void);

static uint64_t g_ticks = 0;

// ============================================================================
// CORREÇÃO: Reduzir TICK_MS de 10ms para 2ms
// Isso aumenta a frequência de polling de 100Hz para 500Hz
// Se ainda for lento, tente 1ms
// ============================================================================
static const uint64_t TICK_MS = 1;  // Era 10, agora é 2

static int g_xhci_poll_counter = 0;
static const int XHCI_POLL_THRESHOLD = 1;  // Poll a cada tick

// Shell tick não precisa ser tão frequente - a cada 20ms é suficiente
static int g_shell_tick_counter = 0;
static const int SHELL_TICK_DIVIDER = 10;  // 2ms * 10 = 20ms

void timer_init(void)
{
    g_ticks = 0;
    g_xhci_poll_counter = 0;
    g_shell_tick_counter = 0;

    uint8_t apic_id = (uint8_t)lapic_get_id();
    hpet_configure_timer0_irq(32, apic_id);

    hpet_set_timer(TICK_MS);
}

uint64_t timer_get_uptime_ms(void)
{
    return g_ticks * TICK_MS;
}

void timer_sleep(uint64_t ms)
{
    uint64_t start_ticks = g_ticks;

    uint64_t ticks_to_wait = (ms + TICK_MS - 1) / TICK_MS;

    if (ticks_to_wait == 0 && ms > 0)
        ticks_to_wait = 1;

    uint64_t target_ticks = start_ticks + ticks_to_wait;

    while (g_ticks < target_ticks)
    {
        __asm__ volatile("hlt");
    }
}

void timer_handler(void)
{
    g_ticks++;

    // Cursor blink / coisa leve ok
    g_shell_tick_counter++;
    if (g_shell_tick_counter >= SHELL_TICK_DIVIDER)
    {
        shell_on_tick();
        g_shell_tick_counter = 0;
    }

    // Poll só marca flag (barato)
    g_xhci_poll_counter++;
    if (g_xhci_poll_counter >= XHCI_POLL_THRESHOLD)
    {
        xhci_poll_events();
        g_xhci_poll_counter = 0;
    }

    hpet_set_timer(TICK_MS);
}