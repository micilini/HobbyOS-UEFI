#include "cmd_irq.h"

#include "../../graphics/console.h"
#include "../../libc/string.h"
#include "../../core/irq_stats.h"

static void irq_usage(void)
{
    console_write("Uso:\n");
    console_write("  irq            - mostra estatisticas simples de IRQ\n");
    console_write("  irq reset      - zera contadores\n");
    console_write("Alias:\n");
    console_write("  int            - igual a irq\n");
}

int cmd_irq(int argc, char **argv)
{
    if (argc >= 2)
    {
        if (strcmp(argv[1], "reset") == 0)
        {
            irq_stats_reset();
            console_write("[IRQ] Contadores zerados.\n");
            return 0;
        }
        if (strcmp(argv[1], "help") == 0 || strcmp(argv[1], "?") == 0)
        {
            irq_usage();
            return 0;
        }
    }

    irq_stats_dump();
    return 0;
}